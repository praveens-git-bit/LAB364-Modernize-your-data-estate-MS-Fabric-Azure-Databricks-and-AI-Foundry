from promptflow import tool
import re

@tool
def format_openai_output(text: str) -> str:
    # Replace Markdown-style image URLs with clickable links
    formatted_text = re.sub(r'!\[(.*?)\]\((https?://\S+)\)', r'\1: \2', text)
    
    # Add extra line breaks for better readability if needed
    formatted_text = formatted_text.replace("\n", "\n\n")

    return formatted_text