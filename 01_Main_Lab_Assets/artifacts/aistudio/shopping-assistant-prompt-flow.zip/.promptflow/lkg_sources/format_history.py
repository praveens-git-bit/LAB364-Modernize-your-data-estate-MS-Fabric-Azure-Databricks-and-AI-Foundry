'''
Author: DREAM demo team

Pseudocode:
1. Define a tool-decorated function 'format_history' that takes a list of dictionaries and a string 'chat_input' as inputs.
2. Initialize an empty list 'conversation_history' to hold the formatted conversation entries.
3. Loop through each entry in the input list 'data':
    a. Extract the user input from the 'inputs' field in the dictionary.
    b. Extract the assistant output from the 'outputs' field in the dictionary.
    c. Add the user input to the 'conversation_history' list, prefixed with "user:".
    d. If there is an assistant output, add it to the 'conversation_history' list, prefixed with "assistant:".
4. Join all entries in 'conversation_history' into a single string separated by newlines.
5. Append the latest 'chat_input' to the end of the concatenated string, prefixed with "user:".
6. Return the final concatenated string as the output.
'''

from promptflow import tool

@tool
def format_history(data, chat_input: str) -> str:
    conversation_history = []
    for entry in data:
        user_input = entry.get("inputs", {}).get("chat_input", "")
        assistant_output_raw = entry.get("outputs", {}).get("chat_output", "")

        # Add user input to conversation history
        conversation_history.append(f"user: {user_input}")

        # Check if assistant output exists and add it to conversation history
        if assistant_output_raw:
            conversation_history.append(f"assistant: {assistant_output_raw}")

    # Join the conversation history into a single string
    final_output = "\n".join(conversation_history)
    
    # Add the latest chat_input as the last line
    final_output = f"{final_output}\nuser: {chat_input}"
    
    return final_output