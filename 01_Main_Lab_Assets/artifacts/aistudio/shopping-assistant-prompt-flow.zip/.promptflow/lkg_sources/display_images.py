from promptflow import tool
import re

@tool
def format_openai_output(text: str) -> str:
    # Replace image URLs with HTML img tags
    formatted_text = re.sub(r'(https?://\S+)', r'<img src="\1" alt="Image" style="width:100px;height:auto;">', text)
    
    # Add extra line breaks for better readability if needed
    formatted_text = formatted_text.replace("\n", "<br><br>")
    
    return formatted_text

