# Build Your Own Shopping Assistant

This demo showcases a **shopping assistant** chatbot powered by Azure services. The chatbot utilizes indexed data, Prompty files and prompt flow to generate fashion look recommendations based on user input. It processes user chat history, preferences, and available products to provide tailored shopping assistance. The implementation involves embedding the raw query, using vector search to find relevant context in user data, and employing GPT along with Prompty files to generate fashion recommendations.

## What does it contain?

This demo kit is designed to help users build their own shopping assistant using Prompty files and prompt flow. It demonstrates a similar functionality to the original shopping assistant but is implemented using Prompty flows within Promptflow.

## Prerequisites

- Connection: Azure OpenAI or OpenAI connection, with the availability of chat and embedding models/deployments.

## Tools used in this demo

- Embedding tool
- Vector Index Lookup tool
- Python tool

## Overview of Components

### Generate Prompt Context
This function takes search result entities and formats them into a string suitable for use by the chatbot. It integrates retrieved documents by extracting and formatting the required content.

### Format History
This function converts the chat history, which is in list format, into a single string. It ensures the conversation flow is maintained by adding user inputs and assistant responses sequentially.

### Modify Query
This function refines the input chat history to generate a more suitable query for AI searches. It loads and executes a Prompty flow designed to enhance the quality of the generated search query.

### Generate Look
This function creates fashion look recommendations based on user inputs such as chat history, product, style, and gender preferences. It uses a Prompty flow to integrate these elements and produce a comprehensive fashion look.

### Format Response
This function processes the dictionary string obtained from generating looks and converts it into a human-readable chat message. It formats and displays fashion looks in an organized manner.

## How It Works

1. **Generate Prompt Context**: Extracts and formats relevant content from search results.
2. **Format History**: Converts and maintains conversation history for continuity in chat.
3. **Modify Query**: Enhances chat history to generate a refined query for AI search.
4. **Generate Look**: Integrates user preferences and chat inputs to recommend fashion looks.
5. **Format Response**: Formats the final output for a user-friendly chat experience.

## How to Use It

Users can download the zip file and get started.

### Installing Prompt Flow on your Machine

To install Prompt Flow, you will need Python on your machine. Use Python 3.9 or higher. Without using a Python virtual environment, you can just run the following command to install Prompt Flow:

```sh
pip install promptflow promptflow-tools
```

Next, run `pf -v` to check the installation. Do not forget to install `promptflow-tools` because it enables the embedding tool, LLM tool, and other tools to be used as nodes in the flow; also ensure this package is installed in the container image that will be created for this flow.

In Visual Studio Code, install the Prompt Flow for VS Code extension. It has the VS Code Python Extension as a prerequisite. Be sure to check the Prompt Flow Quick Start for full instructions. Note that the `pf` command can be used to perform many of the tasks we will discuss below (e.g., creating connections, running a flow, etc.).

## Important Links

- [Installation — Prompt Flow documentation](https://microsoft.github.io/promptflow/how-to-guides/installation/index.html)
- [Getting started with Prompty — Prompt Flow documentation](https://microsoft.github.io/promptflow/tutorials/prompty-quickstart.html)
- [Prompt Flow in Azure AI Studio — Azure AI Studio | Microsoft Learn](https://learn.microsoft.com/en-us/azure/ai-studio/how-to/prompt-flow)

This demo is a practical kit to help users easily build their own shopping assistant using Prompty files. It offers a hands-on approach to integrating advanced GPT capabilities into a personalized shopping experience.