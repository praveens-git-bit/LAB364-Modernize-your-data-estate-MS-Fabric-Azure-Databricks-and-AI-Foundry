from promptflow import tool
from datetime import date
from datetime import datetime

# The inputs section will change based on the arguments of the tool function, after you save the code
# Adding type to arguments and return value will help the system show the types properly
# Please update the function name/signature per need
@tool
def collate_data(answer: str, question: str, content_safety_result: dict) -> dict:
    today = date.today()
    today = today.strftime("%m/%d/%y")
    now = datetime.now()
    current_time = now.strftime("%H:%M:%S")
    data = {
        "question": question,
        "answer": answer,
        "date": today,
        "time": current_time,
        "content_safety": content_safety_result["action_by_category"]
    }
    return data
