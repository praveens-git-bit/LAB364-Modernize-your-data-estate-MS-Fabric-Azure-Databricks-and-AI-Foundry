from typing import List
from promptflow import tool
from promptflow_vectordb.core.contracts import SearchResultEntity

@tool
def generate_prompt_context(search_result: List[dict]) -> str:
    # Helper function to format individual documents
    def format_doc(doc: dict):
        return f"Content: {doc['Content']}\nSource: {doc['Source']}"

    # Define keys for metadata extraction
    SOURCE_KEY = "metadata_storage_name"
    
    # Initialize a list to store formatted results
    retrieved_docs = []
    
    # Loop through each search result
    for item in search_result:
        # Convert item to SearchResultEntity (if needed)
        entity = SearchResultEntity.from_dict(item)
        
        # Extract the content (text) and set default as empty if missing
        content = entity.text or ""
        
        # Initialize source as an empty string
        source = ""
        
        # Extract source from metadata if available
        if entity.metadata is not None:
            if SOURCE_KEY in entity.metadata:
                source = entity.metadata[SOURCE_KEY] or ""
        
        # Append the formatted result to the list
        retrieved_docs.append({
            "Content": content,
            "Source": source
        })
    
    # Join all documents into a single string
    doc_string = "\n\n".join([format_doc(doc) for doc in retrieved_docs])
    
    # Return the final formatted string
    return doc_string
