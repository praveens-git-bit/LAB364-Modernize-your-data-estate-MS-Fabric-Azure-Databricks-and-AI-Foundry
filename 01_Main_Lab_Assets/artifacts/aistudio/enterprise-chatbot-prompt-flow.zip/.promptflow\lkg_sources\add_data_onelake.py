from promptflow import tool
from azure.storage.filedatalake import (
    DataLakeServiceClient,
    DataLakeDirectoryClient,
    FileSystemClient
)
import os
from azure.identity import DefaultAzureCredential
from azure.identity import ClientSecretCredential

ACCOUNT_NAME = "onelake"
WORKSPACE_NAME = "FabricwithAIStudioDemo"
DATA_PATH = "Lakehouse.Lakehouse/Files/fabric_AIStudio_output/ChatOutput"
tenant_id="f94768c8-8714-4abe-8e2d-37a64b18216a"
client_id="4906ddbb-05bd-46bd-9e16-76bb154b9af0"
client_secret="c6R8Q~Whn9hk~5LZmvXomsKxum5WvM2kcMcEFcBf"
credential = ClientSecretCredential(tenant_id,client_id,client_secret)

# The inputs section will change based on the arguments of the tool function, after you save the code
# Adding type to arguments and return value will help the system show the types properly
# Please update the function name/signature per need

@tool
def adding_data_to_fabric(path: str) -> str:
    account_url = f"https://{ACCOUNT_NAME}.dfs.fabric.microsoft.com"
    # token_credential = DefaultAzureCredential()
    service_client = DataLakeServiceClient(account_url, credential=credential)
    file_system_client = service_client.get_file_system_client(file_system = WORKSPACE_NAME)

    onelake_filename = path.split('/')[-1]
    directory_client = file_system_client.get_directory_client(DATA_PATH)
    file_client = directory_client.get_file_client(onelake_filename)

    with open(file=path, mode='rb') as data:
        file_client.upload_data(data, overwrite=True)

    os.remove(path)

    return True