from promptflow import tool
import os
import uuid
import json

# The inputs section will change based on the arguments of the tool function, after you save the code
# Adding type to arguments and return value will help the system show the types properly
# Please update the function name/signature per need
@tool
def creating_json_file(data: dict) -> str:
    json_data = json.dumps(data)
    current_dir = os.getcwd()
    filename = str(uuid.uuid4()) + '.json'
    filename_with_path = os.path.join(current_dir, filename)
    with open(filename_with_path, "w") as file:
        file.write(json_data)
    return filename_with_path