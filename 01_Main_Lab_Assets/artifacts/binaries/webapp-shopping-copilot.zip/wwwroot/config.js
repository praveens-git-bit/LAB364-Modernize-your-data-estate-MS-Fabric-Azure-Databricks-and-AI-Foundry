window.config = {
  SPEECH_KEY: "",
  SPEECH_REGION: "eastus",
  BlobBaseUrl: "https://dreamdemoassets.blob.core.windows.net/openai/",
  IconBlobBaseUrl:
    "https://dreamdemoassets.blob.core.windows.net/openai/left-nav-icons/",
  COPILOT_API:
    "https://#func_shopping_copilot#.azurewebsites.net/api/chat",
  demoMenus: [
    {
      id: 56,
      demoId: 53,
      url: null,
      name: "Build Your Own Shopping Assistant",
      order: 2,
      icon: "https://dreamdemoassets.blob.core.windows.net/openai/aoai_2_shopping.png",
      arrowIcon: null,
      demoSubMenus: [
        {
          id: 3,
          url: "/shopping-assistant",
          name: "Shopping Assistant",
          icon: "https://dreamdemoassets.blob.core.windows.net/openai/shopping_assistant_icon.png",
          arrowIcon: null,
          order: 1,
          componentId: 3,
          componentName: "shopping copilot",
          componentParameters: [],
          externalArrows: [],
          personaId: 1,
          personaName: "Anna",
          personaImageUrl:
            "https://openaidemoassets.blob.core.windows.net/personas/Anna.png",
        },
      ],
      componentParameters: [],
      externalArrows: [],
      componentId: null,
      componentName: null,
      personaId: null,
      personaName: "April",
      personaDesignation: "Chief Executive Officer",
      personaImageUrl:
        "https://openaidemoassets.blob.core.windows.net/personas/April.png",
    },
  ],
  id: 410,
  userId: 85,
  customerId: 374,
  industryId: 1,
  preFillCredentials: true,
  customerName: "Contoso",
  customerEmail: "anna@city.gov.cs",
  name: "Contoso",
  password: "12345",
  title: "Contoso",
  logoImageURL:
    "https://dreamdemoassets.blob.core.windows.net/openai/New_Contoso/top_left_logo_CONTOSO.png",
  backgroundImageURL:
    "https://dreamdemoassets.blob.core.windows.net/openai/aoai_2_login_background.png",
  chatImageLogoURL:
    "https://dreamdemoassets.blob.core.windows.net/openai/aoai_2_chat_logo.png",
  backgroundColor: null,
  primaryColor: "#00a1cbff",
  secondaryColor: "#004b76ff",
  headerImageUrl:
    "https://dreamdemoassets.blob.core.windows.net/openai/contoso_top_level_header_bg.png",
  headerBgColor: "rgba(97, 160, 4, 1)",
  navImageUrl:
    "https://dreamdemoassets.blob.core.windows.net/openai/contoso_left_nav_bg.png",
  userName: "April@contoso.com",
  loginBoxImage:
    "https://dreamdemoassets.blob.core.windows.net/openai/New_Contoso/CONTOSO_login_visual.png",
  loginBackground:
    "https://dreamdemoassets.blob.core.windows.net/openai/aoai_2_login_background.png",
  loginTextBoxImage:
    "https://dreamdemoassets.blob.core.windows.net/openai/contoso_login_text_box.png",
  disableTitle: true,
  navBarPrimaryColor: "#004b76ff",
  navBarSecondaryColor: "#004b76ff",
  navBarTextColor: "rgba(255, 255, 255, 1)",
  tabPrimaryColor: "#00a1cbff",
  tabSecondaryColor: "#004b76ff",
  dropdownPrimaryColor: "#00a1cbff",
  dropdownSecondaryColor: "#004b76ff",
  scrollBarPrimaryColor: "rgba(255, 255, 255, 0.5)",
  scrollBarSecondaryColor: "#004b76ff",
  tabTextColor: "rgba(255, 255, 255, 1)",
  chatApproach: null,
  guid: "9fc02dce-55d7-4e23-8007-58566b55e3a1",
  showSettings: true,
  chatContainerBackgroundColor: "rgba(0, 75, 118, 1)",
};
