import azure.functions as func
import logging
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.ai.contentsafety import ContentSafetyClient
from azure.ai.contentsafety.models import AnalyzeTextOptions
from azure.core.exceptions import HttpResponseError
from azure.search.documents.models import VectorizedQuery
import os
import re
import json
import openai
import time
from datetime import datetime
import cv2
import base64
import ast
import asyncio
import requests
import semantic_kernel as sk
import tempfile
from semantic_kernel.connectors.ai.open_ai.services.open_ai_chat_completion import OpenAIChatCompletion
from azure.cosmos import CosmosClient, PartitionKey, exceptions
from semantic_kernel.connectors.ai.open_ai import AzureChatCompletion
from dotenv import load_dotenv
load_dotenv()

AZURE_OPENAI_SERVICE = os.environ.get("AZURE_OPENAI_SERVICE_GPT4O")
AZURE_OPENAI_MODEL = os.environ.get("AZURE_OPENAI_MODEL_GPT4O") 
AZURE_OPENAI_SERVICE_KEY=os.environ.get("AZURE_OPENAI_SERVICE_KEY_GPT4O")
AZURE_OPENAI_API_BASE = os.environ.get("AZURE_OPENAI_API_BASE_GPT4O")
AZURE_OPENAI_VERSION = os.environ.get("AZURE_OPENAI_VERSION_GPT4O")
AZURE_CONTENT_SAFETY_ENDPOINT = os.environ.get("AZURE_CONTENT_SAFETY_ENDPOINT")
AZURE_CONTENT_SAFETY_KEY = os.environ.get("AZURE_CONTENT_SAFETY_KEY")
AZURE_CONTENT_SAFETY_API_VERSION = os.environ.get("AZURE_CONTENT_SAFETY_API_VERSION")

AZURE_OPENAI_EMBEDDING = os.environ.get("AZURE_OPENAI_EMBEDDING")

service_endpoint = os.environ.get("AZURE_AI_SEARCH_ENDPOINT")
index_name = os.environ.get("AZURE_AI_INDEX_NAME")
key = os.environ.get("AZURE_AI_SEARCH_API_KEY")
openai.api_type = "azure"
openai.api_base = AZURE_OPENAI_API_BASE
openai.api_version = AZURE_OPENAI_VERSION
openai.api_key = AZURE_OPENAI_SERVICE_KEY


host = os.environ.get("AZURE_COSMOSDB_HOST")
master_key = os.environ.get("AZURE_COSMOSDB_MASTER_KEY")
database_id = os.environ.get("AZURE_COSMOSDB_DATABASE_ID")
container_id = os.environ.get("AZURE_COSMOSDB_CONTAINER_ID")
client = CosmosClient(host, master_key)

SEARCH_CLIENT = SearchClient(str(service_endpoint), str(index_name), AzureKeyCredential(str(key)))

kernel = sk.Kernel()
kernel.add_text_completion_service("azureopenai", AzureChatCompletion(AZURE_OPENAI_MODEL, AZURE_OPENAI_API_BASE, AZURE_OPENAI_SERVICE_KEY))
# logging.info("kernel made")

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)


def get_product_images_hardcoded():
    products = {
            "Look 1":[
                        {
                            "name": "Sleeveless Yellow Dress",
                            "url": "https://stiqappdev.blob.core.windows.net/cog-search-product-images/Women_Top_Musturd_Yellow.png",
                            "price": "$ 770"
                        },
                        {
                            "name":"Yellow Handbag",
                            "url":"https://stiqappdev.blob.core.windows.net/cog-search-product-images/women_handbags5.png",
                            "price":"$ 89"
                        },
                        {
                            "name":"Golden Yellow Heels",
                            "url": "https://stiqappdev.blob.core.windows.net/cog-search-product-images/Women_Shoes_Musturd_Yellow_Heels.png",
                            "price": "$ 38"
                        },
                        {
                            "name":"Diamond Necklace with Yellow Stones",
                            "url":"https://stiqappdev.blob.core.windows.net/cog-search-product-images/women_necklace1.png",
                            "price":"$ 200"
                        }
                    ],
                    "Look 2":[
                        {
                            "name": "Shoulderless Long Turquoise Green Dress",
                            "url": "https://stiqappdev.blob.core.windows.net/cog-search-product-images/Look%2026.png",
                            "price": "$ 220"
                        },
                                                    {
                            "name":"Brown and Black Sandals",
                            "url":"https://stiqappdev.blob.core.windows.net/cog-search-product-images/shutterstock_2155926193.jpg",
                            "price":"$ 100"
                        },
                        {
                            "name":"Yellow Handbag",
                            "url":"https://stiqappdev.blob.core.windows.net/cog-search-product-images/women_handbags5.png",
                            "price":"$ 89"
                        },
                        {
                            "name":"Diamond Long Green Earrings",
                            "url":"https://stiqappdev.blob.core.windows.net/cog-search-product-images/women_earrings_blue_diamond.png",
                            "price":"$ 38"
                        }

                    ],
                    "Look 3":[
                        {
                            "name":"Golden Yellow Shirt",
                            "url":"https://stiqappdev.blob.core.windows.net/cog-search-product-images/Women_Top_Musturd_Yellow.png",
                            "price":"$ 66"
                        },
                        {
                            "name":"Diamond Necklace with Yellow Stones",
                            "url":"https://stiqappdev.blob.core.windows.net/cog-search-product-images/women_necklace1.png",
                            "price":"$ 1000"
                        },
                        {
                            "name":"Yellow Canvas Shoes",
                            "url":"https://stiqappdev.blob.core.windows.net/cog-search-product-images/yellow_canvas_shoes.png",
                            "price":"$ 95"
                        }
                    ]
                }
    return products

def ask_style_preference_hardcoded():
    
    return "Fantastic! To pick the perfect outfits for you, I'd love to know what clothing style you usually prefer. Do you gravitate more towards comfortable casual, sleek formal, or a mix of both in semi-formal?"

def hardoded_replies(history):
    # logging.info("here")
    flag = False
    query = history[-1]['user']
    if query == "I am going to Greece for a summer vacation. Can you please show me some outfits for my vacation?":
        flag = True
        answer = "That sounds like an exciting trip! To help you look your best, could you let me know if you lean more towards casual, formal, or semi-formal clothing?"
        products = {}
        #answer = "Sure, I can help you with that. Here are some looks I have created for you based on the products available."
        flag = True
        return flag, products,answer
    elif query == "I lean more towards casual clothing. Comfort is my priority when choosing an outfit, especially when traveling." or  query == "I lean more towards casual clothing. Comfort is my priority when choosing an outfit, especially when traveling":
        time.sleep(7)  # Delay before responding
        answer = ask_style_preference_hardcoded()
        flag = True
        products = {}
        return flag, products,answer  
    elif query == "Regarding clothing style, I tend to choose pieces that are classic and timeless. I also love outfits that I can mix and match." or query == "Regarding clothing style, I tend to choose pieces that are classic and timeless. I also love outfits that I can mix and match":
        time.sleep(7)  # Delay before responding
        # Show products
        products = get_product_images_hardcoded()
        answer = "Sure, I can help you with that. Here are some looks I have created for you based on the products available."
        flag = True
        return flag, products, answer  
    return False,'',''

def get_last_user_message(history):
    last_user_info = re.findall(r'user - (.*?)(?=bot -|$)', history, re.DOTALL)[-1].strip()
    return last_user_info

def get_embeddings(query):
    response = openai.Embedding.create(
    input=query,
    engine=AZURE_OPENAI_EMBEDDING)
    embeddings = response['data'][0]['embedding']
    return embeddings

def get_category_severity(category_string,category_list):
    for category_obj in category_list:
        if(category_obj.category == category_string):
            return category_obj.severity
    return 0

def get_chatgpt_messages_content_safety(input):
    messages = [
        {
            "role":"user",
            "content":input
        }
    ]

    return messages

def get_chatgpt_response(input,temperature=1,max_tokens=256,frequency_penalty=0,presence_penalty=0,stop=None,top_p=1.0):
    response = openai.ChatCompletion.create(
        engine=AZURE_OPENAI_MODEL,
        messages = input,
        temperature=temperature,
        max_tokens=max_tokens,
        top_p=top_p,
        frequency_penalty=frequency_penalty,
        presence_penalty=presence_penalty,
        stop=stop)
    
    return response.choices[0].message.content

def ensure_content_safety(content):
    key = AZURE_CONTENT_SAFETY_KEY
    endpoint = AZURE_CONTENT_SAFETY_ENDPOINT
    client = ContentSafetyClient(endpoint, AzureKeyCredential(key))
    request = AnalyzeTextOptions(text=content)

    results = {}

    try:
        response = client.analyze_text(request)
        jailbreak_res = detect_jailbreak(content)
    except HttpResponseError as e:
        if e.error:
            print(f"Error code: {e.error.code}")
            print(f"Error message: {e.error.message}")
            raise
        raise

    if response.categories_analysis:
        results['hate'] = get_category_severity('Hate',response.categories_analysis)
        results['SelfHarm'] = get_category_severity('SelfHarm',response.categories_analysis)
        results['sexual'] = get_category_severity('Sexual',response.categories_analysis)
        results['violence'] = get_category_severity('Violence',response.categories_analysis) 

    violations = []
    for key, value in results.items():
        if value > 0:
            violations.append(key)

    if jailbreak_res == True:
        violations = "Jailbreak attempt"

    if violations:
        # logging.info("here")
        reasons = ", ".join(violations)
        prompt = f"Please tell the user that the query is rejected due to Contoso's Content Policy and ask them to reframe. Also let them know the reason from the results because of {reasons}. No prose."
        input = get_chatgpt_messages_content_safety(prompt)
        response_for_safety = get_chatgpt_response(input)
        return False,response_for_safety
    else:
        return True,"CONTENT IS SAFE"

def detect_jailbreak(content):
    headers = {
    "Content-Type": "application/json",
    "Ocp-Apim-Subscription-Key": AZURE_CONTENT_SAFETY_KEY}
    url = f"{AZURE_CONTENT_SAFETY_ENDPOINT}/contentsafety/text:detectJailbreak?api-version={AZURE_CONTENT_SAFETY_API_VERSION}"
    payload = {
    "text": content}
    
    response = requests.post(url, headers=headers, data=json.dumps(payload))
    response_data = response.json()
    # logging.info(response)
    if response_data['jailbreakAnalysis']['detected']:
        return True
    else:
        return False

def reformat_json_to_text(history):
    text = ''
    for message in history:
        if 'user' in message:
            text += 'user - ' + message['user'] + '\n'
        if 'bot' in message:
            text += 'bot - ' + message['bot'] + '\n'
    return text

def collate_dictionaries(looks,products):
    result = {}
    for look, products_list in looks.items():
        if look != "eva_response":
            result[look] = []
            for product in products_list:
                for item in products:
                    if product == item['product_name']:
                        result[look].append(
                            {'name': item['product_name'], 
                            'id': item['id'],
                            'url': item['url'],
                            'price':item['price']})
    for key in result.keys():
        result[key] = list({v['name']:v for v in result[key]}.values())
    return result

def crop_product_list(product_list_string, percentage):
    target_length = int(len(product_list_string) * percentage)
    # Split the string by commas to get individual products
    products = product_list_string.split(',')
    # Use a list comprehension with cumulative length logic
    current_length = 0
    cropped_products = [product for product in products 
                        if (current_length := current_length + len(product) + 1) <= target_length]
    # Join the cropped products back into a string
    return ','.join(cropped_products)

def search_items(query):
    start_time = time.time()
    # logging.info("Starting search")
    embedding = get_embeddings(query)
    vector_query = VectorizedQuery(vector=embedding, k_nearest_neighbors=70, fields="vector_embedding")
    results = SEARCH_CLIENT.search(  
    search_text=None,  
    vector_queries= [vector_query],
    select=["id", "product", "imageUrl","gender","price"]) 
    results_list = results
    fetch_time = time.time()
    # logging.info(f"Search completed. Fetch time: {fetch_time - start_time}s")
    # logging.info(results_list)
    product_name_list_for_male = []
    product_name_list_for_unisex = []
    product_name_list_for_female = []
    search_dictionary = []
    # Processing the results
    for result in results_list:
        try:
            if result['gender'] == 'Male':
                product_name_list_for_male.append(str(result['product']))
            elif result['gender'] == 'Unisex':
                product_name_list_for_unisex.append(str(result['product']))
            elif result['gender'] == 'Female':
                product_name_list_for_female.append(str(result['product']))
            product_dict = {
                "id": result['id'],
                "product_name": result['product'],
                "url": result['imageUrl'],
                "price": "$" + str(result['price'])
            }
            search_dictionary.append(product_dict)
        except KeyError as e:
            print(f"Missing key: {e}")
    product_name_list_for_male = ','.join(product_name_list_for_male)
    product_name_list_for_unisex = ','.join(product_name_list_for_unisex)
    product_name_list_for_female = ','.join(product_name_list_for_female)
    product_name_list = "FEMALE: " + product_name_list_for_female + "MALE: "+  product_name_list_for_male + "UNISEX: " + product_name_list_for_unisex
    return product_name_list,search_dictionary

def get_looks_without_semantic_kernel(products, context, query, style, gender,looks,temperature=0.22,max_tokens=2500,frequency_penalty=0,presence_penalty=0,stop=None,top_p=1.0):
    prompt = f"""You are a style assistant. Your work is to provide looks to the customer based on the products available in the store.
    Following are the instructions you have to follow:
    1. You are given the history of the conversation, products available and the looks that have been showed before.
    2. From the conversation and the products, you have to provide a look. A look consists of minimum three to maximum four items - clothing, footwear, accessories
    3. You are supposed to ask questions to the user to make sure you have idea about occasion, place and time for which they are shopping.
    4. From the place and time, extract the weather condtion and use that for your recommendation.
    5. Keep adjusting and changing the look based on the conversation. Always try to send looks.
    6. You are supposed to give product recommendation based on the products listed below.
    7. If you do not have required products you are allowed to say its not available like traditional male dress.
    8. NEVER ask about gender as it is a sensitive issue.
    9. Be cheerful and natural. There is no need to thank the customer at every step, as it looks fake.
    10. If you are asked to modify given look, see the PREVIOUS LOOK section.
    ---
    Required Information:
    CONVERSATION:
    {context}
    {query}
    --
    PRODUCTS:
    {products}
    --
    PREFERRED STYLE: {style}
    USER GENDER: {gender}
    PREVIOUS LOOK:
    {looks}
    --
    The output format should ALWAYS be a python dictionary with the following structure:
    {{"eva_response": "your response as a stylist","Look 1":["clothing piece", "accessory", "footwear"],"Look 2":[]..}}

    eva_response is the response you give as a stylist. Give exact names even the ' like in "Men's" without the \ as it needs to be looked up in database.
    """
    
    messages=[
        {
            "role": "user",
            "content": prompt,
        }
    ]

    # logging.info(prompt)
    response = openai.ChatCompletion.create(
        engine=AZURE_OPENAI_MODEL,
        messages = messages,
        temperature=temperature,
        max_tokens=max_tokens,
        top_p=top_p,
        frequency_penalty=frequency_penalty,
        presence_penalty=presence_penalty,
        stop=stop)
    
    # logging.info(response.choices[0].message.content)
    return response.choices[0].message.content

async def get_looks(products, query,context,style,gender):
    pluginsDirectory = "plugins-sk"
    # logging.info(products)
    pluginBT = kernel.import_semantic_skill_from_directory(pluginsDirectory, "evaPlugin");
    sk_context = kernel.create_new_context()
    sk_context['query'] = query
    sk_context['products'] = products
    sk_context['style'] = style
    sk_context['gender'] = gender
    # logging.info(f"CONTEXTTTTTTTTTTT {context}")
    sk_context['conversation_context'] = context
    try:
        oai_res = await kernel.run_async(pluginBT["conversationPlugins"], input_context=sk_context)
    except Exception as e:
        return str(e)
    return oai_res

async def optimise_query(conversation_history,gender):
    pluginsDirectory = "plugins-sk"
    pluginBT = kernel.import_semantic_skill_from_directory(pluginsDirectory, "evaPlugin");
    sk_context = kernel.create_new_context()
    sk_context['conversation'] = conversation_history
    sk_context['user_gender'] = gender
    try:
        oai_res = await kernel.run_async(pluginBT["optimisationPlugins"], input_context=sk_context)
    except Exception as e:
        return str(e)
    return oai_res

async def identify_gender(complete_conversation,third_person_style, is_third_person_present,third_person_gender):
    pluginsDirectory = "plugins-sk"
    pluginBT = kernel.import_semantic_skill_from_directory(pluginsDirectory, "evaPlugin");
    sk_context = kernel.create_new_context()
    conversation_history = reformat_json_to_text(complete_conversation)
    sk_context['is_third_person_present'] = is_third_person_present
    sk_context['third_person_style'] = third_person_style
    sk_context['third_person_gender'] = third_person_gender
    sk_context['conversation'] = conversation_history
    try:
        oai_res = await kernel.run_async(pluginBT["genderPlugins"], input_context=sk_context)
        # logging.info("here2")
    except Exception as e:
        return str(e)
    return oai_res

async def suggest_triggers(products, query, context, style, gender, looks):
    pluginsDirectory = "plugins-sk"
    # logging.info('Get_suggestion')
    pluginBT = kernel.import_semantic_skill_from_directory(pluginsDirectory, "evaPlugin");
    sk_context = kernel.create_new_context()
    sk_context['current_looks'] = query
    # logging.info(f'---Current_Looks---{query}')
    # sk_context['products'] = products
    sk_context['style'] = style
    sk_context['gender'] = gender
    sk_context['conversation_history'] = context
    s = ast.literal_eval(looks)
    sk_context['query'] = str(s['eva_response'])
    # logging.info(f"---Query---{str(s['eva_response'])}")
    try:
        oai_res = await kernel.run_async(pluginBT["SuggesterPlugin"], input_context=sk_context)
    except Exception as e:
        return str(e)
    return oai_res

async def optimise_conversation(conversation_history):
    pluginsDirectory = "plugins-sk"
    pluginBT = kernel.import_semantic_skill_from_directory(pluginsDirectory, "evaPlugin");
    sk_context = kernel.create_new_context()
    sk_context['conversation'] = conversation_history
    try:
        oai_res = await kernel.run_async(pluginBT["contextConversation"], input_context=sk_context)
    except Exception as e:
        return str(e)
    return oai_res

def modify_conversation_by_third_person(conversation_history):
    pattern = r'Look (\d+) selected.'
    look_preferences={
        '1':". The person is female and she prefers casuals.",
        '2':". The person is female and she prefers formals.",
        '3':". The person is male and he prefers casuals.",
        '4':". The person is male and he prefers formals.",
    }
    modified_converstaion = []
    for i in range(len(conversation_history)):
        conversation = conversation_history[i]
        # match = re.search(pattern, conversation["user"])
        match = re.fullmatch(pattern, conversation["user"])
        if match:
            number = match.group(1)
            modified_converstaion[-1]["user"] = modified_converstaion[-1]["user"]+look_preferences[number]     
            if('bot' in conversation):
                modified_converstaion[-1]["bot"] = conversation["bot"]
            else:
                modified_converstaion[-1].pop("bot")
        else:
            modified_converstaion.append(conversation)
    return modified_converstaion

def modify_message_third_person(last_user_message):
    pattern = r'Look (\d+) selected.'
    look_preferences={
        '1':". The person is female and she prefers casuals.",
        '2':". The person is female and she prefers formals.",
        '3':". The person is male and he prefers casuals.",
        '4':". The person is male and he prefers formals.",
    }
    match = re.fullmatch(pattern, last_user_message)
    if match:
        number = match.group(1)
        modified_last_user_message = last_user_message+look_preferences[number]     
    else:
        modified_last_user_message = last_user_message
    return modified_last_user_message

def save_chat_to_cosmosdb(history,answer,sessionid,gender,style):
    db = client.get_database_client(database_id)
    container = db.get_container_client(container_id)
    history[-1]["bot"] = answer
    timestamp = datetime.utcnow().isoformat()
    container.upsert_item({
        'id': sessionid,
        'sessionId': sessionid,
        'history': history,
        "gender": gender,
        "style": style,
        "time": timestamp
        })

def get_chat_from_cosmosdb(sessionid):
    db = client.get_database_client(database_id)
    container = db.get_container_client(container_id)
    item_response = container.read_item(item=sessionid, partition_key=sessionid)
    history = item_response['history']
    gender = item_response['gender']
    style = item_response['style']
    return history, gender, style

def delete_chat_from_cosmosdb(sessionid):
    db = client.get_database_client(database_id)
    container = db.get_container_client(container_id)
    try:
        container.delete_item(item=sessionid, partition_key=sessionid)
        res = f"I have deleted the session {sessionid} successfully."
        return res
    except Exception as e:
        res = f"An error occurred: {e}"
        return res

def optimise_conversation_without_semantic_kernel(conversation,gender,temperature=0,max_tokens=70,frequency_penalty=0,presence_penalty=0,stop=None,top_p=1.0):
    prompt = f"""From the following conversation, based on the recent conversation, please give a detailed query that can be used to search for products including occasion, style, preference. The query should be brief. Add appropriate accessory and footwear too like watches, sunglasses etc. Always make sure the query includes clothing, footwear and accessory.
    gender: {gender}
    conversation:
    {conversation}"""
    
    messages=[
        {
            "role": "user",
            "content": prompt,
        }
    ]
    response = openai.ChatCompletion.create(
        engine=AZURE_OPENAI_MODEL,
        messages = messages,
        temperature=temperature,
        max_tokens=max_tokens,
        top_p=top_p,
        frequency_penalty=frequency_penalty,
        presence_penalty=presence_penalty,
        stop=stop)
    
    return response.choices[0].message.content

def suggestion_without_semantic_kernel(conversation,gender,temperature=0,max_tokens=70,frequency_penalty=0,presence_penalty=0,stop=None,top_p=1.0):
    # logging.info("here")
    prompt = f"""CONVERSATION:
{conversation}
Given the above conversation history, suggest some reply for the user.For example if the bot has asked 'what do you plan to do in Greece', the suggestion can be 'I will be exploring the beaches' Make the reply brief and natural. Maximum three reply suggestion.
GENDER: {gender}
The response should be a python list which will be in the following format always:
["First suggestion","Second suggestion",...]. 
SUGGESTION FOR USER:"""
    
    messages=[
        {
            "role": "user",
            "content": prompt,
        }
    ]
    response = openai.ChatCompletion.create(
        engine=AZURE_OPENAI_MODEL,
        messages = messages,
        temperature=temperature,
        max_tokens=max_tokens,
        top_p=top_p,
        frequency_penalty=frequency_penalty,
        presence_penalty=presence_penalty,
        stop=stop)
    
    # logging.info(response.choices[0].message.content)
    return response.choices[0].message.content

def detect_language(input,temperature=0,max_tokens=70,frequency_penalty=0,presence_penalty=0,stop=None,top_p=1.0):
    prompt = f"""Respond with 'english' if the query is in english. Otherwise say 'other'. Verbatim 
ex        
query - Aaj ka din bhut accha hai
res:
other
&nbsp;
query - Today is a nice day
res:
english
&nbsp;
query -  {input}
res: """
    
    messages=[
        {
            "role": "user",
            "content": prompt,
        }
    ]
    response = openai.ChatCompletion.create(
        engine=AZURE_OPENAI_MODEL,
        messages = messages,
        temperature=temperature,
        max_tokens=max_tokens,
        top_p=top_p,
        frequency_penalty=frequency_penalty,
        presence_penalty=presence_penalty,
        stop=stop)
    
    return response.choices[0].message.content

def translate_suggestion_if_required(input,response_,gender,temperature=0,max_tokens=256,frequency_penalty=0,presence_penalty=0,stop=None,top_p=1.0):
    prompt = f"""Translate the answer in the same language and script as original. If it is transliterated, give transliterated response, if fully in script, give fully in script. The gender for the translated/transliterated text should be {gender}.
    If the query is in english, retain the english response. Respond in plain text.
    ex 
    original - aaj mai bahut khush hu       
    text - yes it is
    res:
    haan sahi mei

    original - I am very happy today
    text - yes it is
    res:
    yes it is

    original -  {input}
    text - {response_}
    res: """
    
    messages=[
        {
            "role": "user",
            "content": prompt,
        }
    ]
    response = openai.ChatCompletion.create(
        engine=AZURE_OPENAI_MODEL,
        messages = messages,
        temperature=temperature,
        max_tokens=max_tokens,
        top_p=top_p,
        frequency_penalty=frequency_penalty,
        presence_penalty=presence_penalty,
        stop=stop)
    
    # logging.info(response)
    # res = response.choices[0].message.content
    try:
        res = response.choices[0].message.content    
        return res
    except Exception as e:
        return response_

def translate_if_required(input,response,gender,temperature=0,max_tokens=256,frequency_penalty=0,presence_penalty=0,stop=None,top_p=1.0):
    prompt = f"""Translate the answer in the same language and script as query. If it is transliterated, give transliterated response, if fully in script, give fully in script. Person giving 'query' is {gender} and person giving 'answer' is female.
    If the query is in english, retain the english response. Respond in plain text.  
ex        
query - Aaj ka din bhut accha hai
answer - yes it is
res:
haan sahi mei

query - Today is a nice day
answer - yes it is
res:
yes it is

query -  {input}
answer - {response}
res: """
    
    messages=[
        {
            "role": "user",
            "content": prompt,
        }
    ]
    response = openai.ChatCompletion.create(
        engine=AZURE_OPENAI_MODEL,
        messages = messages,
        temperature=temperature,
        max_tokens=max_tokens,
        top_p=top_p,
        frequency_penalty=frequency_penalty,
        presence_penalty=presence_penalty,
        stop=stop)
    
    return response.choices[0].message.content

def caption_generator_gpt4o(image_data,url):
    if url == "":
        encoded_image= base64.b64encode(image_data).decode('ascii')
    else:    
        # logging.info("why here")
        IMAGE_URL = url
        try:
            image_response = requests.get(IMAGE_URL)
            image_response.raise_for_status()
        except requests.RequestException as e:
            raise SystemExit(f"Failed to fetch image. Error: {e}")
        encoded_image = base64.b64encode(image_response.content).decode('ascii')

    messages = [
      {
        "role": "system",
        "content": [
          {
            "type": "text",
            "text": "You are an AI assistant that helps can describe images impeccably."
          }
        ]
      },
      {
        "role": "user",
        "content": [
          {
            "type": "image_url",
            "image_url": {
              "url": f"data:image/jpeg;base64,{encoded_image}"
            }
          },
          {
            "type": "text",
            "text": "From the given image, provide an overall fashion description of the image. If the image looks like an ensemble or a moodboard, determine the vibe, aesthetic and the outfits given. The answer should be brief, not verbose. We need to search for the items. We want to recreate the look given in image, so add some suggestion on your own, and add accessory and footwear if not there. Brief. No markdown."
          }
        ]
      }
    ]
    
    response = openai.ChatCompletion.create(
        engine=AZURE_OPENAI_MODEL,
        messages = messages,
        temperature=0,
        max_tokens=700,
        top_p=0,
        frequency_penalty=0,
        presence_penalty=0,
        stop=None)
    
    return response.choices[0].message.content

def collate_dictionary(selected_products,all_products):
    # Extract the product names from the selected products
    selected_product_names = selected_products['products']

    # Initialize a list to store the matched products
    matched_products = []

    # Iterate over all the products
    for product in all_products:
        # If the product's name is in the selected names, add it to the matched list
        if product['product_name'] in selected_product_names:
            # Create a new dictionary with the desired structure and append it to the list
            matched_products.append({
                "id": product['id'],
                "name": product['product_name'],
                "url": product['url'],
                "price": product['price']
            })

    # Result contains product info for the matched products
    result = {"Similar Products": matched_products}
    return result

def describe_video_gpt4o(base64Frames):

    image_base_content = [
        {
            "type": "image_url",
            "image_url": {
                "url": f"data:image/jpeg;base64,{frame}"
            }
        }
        for frame in base64Frames[0::110]
    ]
    text_prompt = {
        "type": "text",
        "text": (
            "From the given image, provide an overall fashion description of the image. "
            "If the image looks like an ensemble or a moodboard, determine the vibe, "
            "aesthetic and the outfits given. The answer should be brief, not verbose. "
            "We need to search for the items. We want to recreate the look given in the image, "
            "so add some suggestions on your own, and add accessory and footwear if not there. Brief. "
            "No markdown."
        )
    }
    combined_content = [
        item for pair in zip(image_base_content, [text_prompt] * len(image_base_content))
        for item in pair
    ]

    messages = [
    {
       "role": "user",
        "content": combined_content
    }]

    response = openai.ChatCompletion.create(
        engine=AZURE_OPENAI_MODEL,
        messages = messages,
        temperature=0,
        max_tokens=700,
        top_p=0,
        frequency_penalty=0,
        presence_penalty=0,
        stop=None)
    
    return response.choices[0].message.content

def format_looks(data):
    result = []
    if data:
        for look, items in data.items():
            if items:
                item_names = [item['name'] for item in items]
                result.append(f"{look} - {', '.join(item_names)}")
    else:
        return '--'
    return result

async def get_products_(caption,products,type="image"):
    pluginsDirectory = "plugins-sk"
    pluginBT = kernel.import_semantic_skill_from_directory(pluginsDirectory, "evaPlugin");
    sk_context = kernel.create_new_context()
    sk_context['description'] = caption
    sk_context['products'] = products
    sk_context['type'] = type
    try:
        oai_res = await kernel.run_async(pluginBT["imagePlugin"], input_context=sk_context)
    except Exception as e:
        return str(e)
    return oai_res

@app.route(route="chat")
async def chat(req: func.HttpRequest) -> func.HttpResponse: 
    
    time_dictionary = {}

    CONVERSATION = req.params.get('history')
    if not CONVERSATION:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            CONVERSATION = req_body.get('history')

    USER_QUERY = req.params.get('query')
    if not USER_QUERY:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            USER_QUERY = req_body.get('query')

            
    USER_GENDER = req.params.get('gender')
    if not USER_GENDER:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            USER_GENDER = req_body.get('gender')

    USER_STYLE = req.params.get('style')
    if not USER_STYLE:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            USER_STYLE = req_body.get('style')

    PRODUCTS = req.params.get('products')
    if not PRODUCTS:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            PRODUCTS = req_body.get('products')
    LOOKS = format_looks(PRODUCTS) 

    error = False
    error_msg = ''
    try:
        start_time = time.time()
        #format the conversation
        conversation_history = reformat_json_to_text(CONVERSATION)
        end_time = time.time()
        total_time = end_time - start_time
        # logging.info(f"formatting took {total_time} seconds")
        #extract last agent message
        last_user_message = get_last_user_message(conversation_history)
        language = detect_language(last_user_message)
        language = language.lower()
        #check for safety
        # is_safe,content_safety_message = ensure_content_safety(last_user_message)
        is_safe = 'yes'
        if not is_safe:
            if language!="english":
                t_res = translate_if_required(last_user_message,content_safety_message,USER_GENDER)
                content_safety_message = t_res
            return func.HttpResponse(
                    json.dumps(
                                {
                                    "products": [],
                                    "answer": content_safety_message,
                                    "show_default_looks":False,
                                    "suggestions": []
                                }
                            ), mimetype="application/json"
                        )
 

        start_time = time.time()
        #optimise query
        # optimised_query = await optimise_query(conversation_history,USER_GENDER)
        optimised_query = optimise_conversation_without_semantic_kernel(conversation_history,USER_GENDER)
        query = str(optimised_query) + " " + USER_GENDER
        query = query.replace('\"','')
        end_time = time.time()
        total_time = end_time - start_time
        time_dictionary["Optimizing Query"] = round(total_time,4)
        # logging.info(query)
        # logging.info(f"optimizing query took {total_time} seconds")
        # result_dict = json.loads(optimised_query.result)

        if 'error_code' in query:
            error = True
            error_msg = query
        
        start_time = time.time()
        #searching
        search_results,search_dictionary = search_items(query)
        end_time = time.time()
        total_time = end_time - start_time
        time_dictionary["Searching Database"] = round(total_time,4)

        # logging.info(f"Search Results: {search_results}")
        # logging.info(f"search took {total_time} seconds")

        if not error:
            start_time = time.time()
            #getting looks
            if 'RateLimitError' in query or 'error_code' in query:
                error = True
                error_msg = query
            
            if not error:
                # looks = await get_looks(query=query,products=search_results,context=conversation_history,style=USER_STYLE,gender=USER_GENDER)
                start_time = time.time()
                looks = get_looks_without_semantic_kernel(query=query,products=search_results,context=conversation_history,style=USER_STYLE,gender=USER_GENDER, looks = LOOKS)
                end_time = time.time()
                time_dictionary["Creating Looks"] = round(total_time,4)
                looks_as_string = str(looks)
                looks_as_string = looks_as_string.replace("\n","")
                # Remove multiple spaces between words
                looks_as_string = re.sub(r'\s+', ' ', looks_as_string)
                # Remove spaces around curly braces and colons

                looks_as_string = re.sub(r'\s*{\s*', '{', looks_as_string)
                looks_as_string = re.sub(r'\s*}\s*', '}', looks_as_string)
                looks_as_string = re.sub(r'\s*:\s*', ':', looks_as_string)

                pattern = r"\{.*?\}"
                # Find the first match of the pattern in the input string
                match = re.search(pattern, looks_as_string)
                # Output the match if found
                extracted_dict = match.group(0)
                looks_dict = ast.literal_eval(extracted_dict)
                looks_res = collate_dictionaries(looks_dict,search_dictionary)
                
                if 'RateLimitError' in looks_as_string or 'error_code' in looks_as_string:
                    error = True
                    error_msg = looks_as_string
                
                if not error:
                    try:
                        conversation_history = conversation_history + "\nbot:" + looks_dict['eva_response']
                        start_time = time.time()
                        suggestions = suggestion_without_semantic_kernel(conversation=conversation_history,gender = USER_GENDER) 
                        end_time = time.time()
                        time_dictionary["Creating Suggestions"] = round(total_time,4)
                        suggestions_as_string = str(suggestions)
                        suggestions_as_string = suggestions_as_string.replace("\n","")
                        pattern = r"\[.*?\]"
                        match = re.search(pattern, suggestions_as_string)
                        extracted_dict = match.group(0)

    
                        suggestions_list = ast.literal_eval(extracted_dict)
                        # logging.info(suggestions_list)
                        if language!="english":
                            start_time = time.time()
                            translated_suggestion = []
                            for items in suggestions_list:
                                translated_suggestion.append(translate_suggestion_if_required(last_user_message,items,USER_GENDER))
                            suggestions_list = translated_suggestion
                            end_time = time.time()
                            time_dictionary["Translating Suggestions"] = round(total_time,4)

                        # Remove multiple spaces between words
                        # looks_as_string = re.sub(r'\s+', ' ', looks_as_string)
                        # # Remove spaces around curly braces and colons

                        # looks_as_string = re.sub(r'\s*{\s*', '{', looks_as_string)
                        # looks_as_string = re.sub(r'\s*}\s*', '}', looks_as_string)
                        # looks_as_string = re.sub(r'\s*:\s*', ':', looks_as_string)

                        # looks_dict = ast.literal_eval(looks_as_string)
                        looks_result = collate_dictionaries(looks_dict,search_dictionary)
                        end_time = time.time()
                        total_time = end_time - start_time
                        # logging.info(f"getting looks took {total_time} seconds")
                    except Exception as e:
                        error_response = f"Oh no! I encountered some problem while loading the looks. This is the response I received:\n{looks_as_string}\n Lets try again. {e}"
                        if language!="english":
                            t_res = translate_if_required(last_user_message,error_response, USER_GENDER)
                            error_response = t_res
                        return func.HttpResponse(
                            json.dumps(
                                        {
                                            "products": [],
                                            "answer":error_response,
                                            "show_default_looks":False,
                                            "suggestions": []
                                        }
                                    ), mimetype="application/json"
                                )

                    #check for question
                    # if "?" in looks_dict['eva_response']:
                    #     answer = looks_dict['eva_response']
                    #     # logging.info(answer)
                    #     # save_chat_to_cosmosdb(CONVERSATION,answer,SESSIONID,USER_GENDER,USER_STYLE)
                    #     if language!="english":
                    #         start_time = time.time()
                    #         t_res = translate_if_required(last_user_message,answer,USER_GENDER)
                    #         end_time = time.time()
                    #         time_dictionary["Translating Answer"] = round(total_time,4)
                    #         answer = t_res
                    #     return func.HttpResponse(
                    #         json.dumps(
                    #                     {
                    #                         "products": [],
                    #                         "answer":answer,
                    #                         "show_default_looks":False,
                    #                         "suggestions": suggestions_list,
                    #                         "time": time_dictionary
                    #                         # "suggestions": []
                    #                     }
                    #                 ), mimetype="application/json"
                    #             )

        if error == True:
            error_res = f'Oops looks like I have encountered an error - {error_msg}'
            if language!="english":
                t_res = translate_if_required(last_user_message,error_res,USER_GENDER)
                error_res = t_res
            return func.HttpResponse(
                json.dumps(
                    {
                        "products": [],
                        "answer":error_res,
                        "show_default_looks":False,
                        "suggestions": [],
                        "time": time_dictionary
                    }
                ), 
                mimetype="application/json",
                status_code=400
            )


        answer = looks_dict['eva_response']
        # save_chat_to_cosmosdb(CONVERSATION,answer,SESSIONID,USER_GENDER,USER_STYLE)
        if language!="english":
            t_res = translate_if_required(last_user_message,looks_dict['eva_response'],USER_GENDER)
            answer = t_res
        return func.HttpResponse(
            json.dumps(
                {
                    "products": looks_result,
                    "answer":answer,
                    "show_default_looks":False,
                    # "suggestions": suggest_list
                    "suggestions": suggestions_list,
                    "time": time_dictionary
                }
            ), mimetype="application/json"
        )
    except Exception as e:
        # print(e)
        # logging.error("error:", exc_info=True)
        return func.HttpResponse(
            json.dumps(
                {
                    "answer": str(e) + "- Error occured",
                    "products": [],
                    "show_default_looks":False,
                    "suggestions": [],
                    "time": time_dictionary

                }
            ), mimetype="application/json"
        )

